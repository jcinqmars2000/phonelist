package com.steere.ServletExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServletExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServletExampleApplication.class, args);
	}
}
