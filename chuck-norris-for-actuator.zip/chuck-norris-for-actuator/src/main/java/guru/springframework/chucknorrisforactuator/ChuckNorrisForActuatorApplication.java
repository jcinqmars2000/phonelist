package guru.springframework.chucknorrisforactuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChuckNorrisForActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChuckNorrisForActuatorApplication.class, args);
	}
}
