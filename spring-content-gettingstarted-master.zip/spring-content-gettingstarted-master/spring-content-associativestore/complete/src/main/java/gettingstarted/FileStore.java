package gettingstarted;

import org.springframework.content.commons.repository.AssociativeStore;

public interface FileStore extends AssociativeStore<File, String> {
}
